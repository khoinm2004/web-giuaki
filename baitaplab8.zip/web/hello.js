document.write("this	text	was	written	from	JS");
var	count	=	1;
document.write("	Count	=	"	+	count);
count++;
var	output	=	"<br>Count	=	"	+	count;
document.write(output);
doccumment.write	("this	text	was	written	from	JS");
