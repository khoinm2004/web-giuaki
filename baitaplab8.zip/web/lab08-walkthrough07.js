var	daysOfWeek	= new Array("Mon","Tues","Wed","Thur","Fri");
document.write(daysOfWeek+"<br>");
var daysOfWeek = new Array ("Mon","Tues","Wed","Thur","Fri");
daysOfWeek.push("Sat");
daysOfWeek.unshift("Sun");
document.write(daysOfWeek+"<br>");
document.write("<table border=1>");
document.write("<tr>");
for	(var i = 0;	i <	daysOfWeek.length; i++){
    if	(daysOfWeek[i].length <	4)
        day	= daysOfWeek[i];
    else(
        day	= "<em>" + daysOfWeek[i] +	"</em>")
	    document.write("<th>" +	day	+ "</th>");
}
var day = 1; 
    for (var week = 0; week < 5; week++) {
        document.write("<tr>");
        for (var dayofWeek = 0; dayofWeek <7; dayofWeek++){
            if (day <=30){
                document.write("<td>" + day + "</td>");
                day++;
            }else{
                document.write("<td></td>");
            }
        }
        document.write("</tr>");
    }
    document.write("</table>");
document.write("</tr>");
document.write("</table>");

